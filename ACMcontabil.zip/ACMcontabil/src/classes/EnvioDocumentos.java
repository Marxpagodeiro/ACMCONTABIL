package classes;


public class EnvioDocumentos {
    private String dadosPessoais;
    private String codigoPessoa;
    private String dependentes;
    private String codigoDependente;
    private String rendimentos;
    private String codigoRendimento;
    private String bensDireitos;
    private String codigoBenDireito;
    private String dividasOnus;
    private String codigoDividaOnu;
    private String doacoesEfetuadas;
    private String codigoDoacoes;
    private String investimentos;
    private String codigoInvestimneto;

    public EnvioDocumentos(String dadosPessoais, String codigoPessoa, String dependentes, String codigoDependente, String rendimentos, String codigoRendimento, String bensDireitos, String codigoBenDireito, String dividasOnus, String codigoDividaOnu, String doacoesEfetuadas, String codigoDoacoes, String investimentos, String codigoInvestimneto) {
        this.dadosPessoais = dadosPessoais;
        this.codigoPessoa = codigoPessoa;
        this.dependentes = dependentes;
        this.codigoDependente = codigoDependente;
        this.rendimentos = rendimentos;
        this.codigoRendimento = codigoRendimento;
        this.bensDireitos = bensDireitos;
        this.codigoBenDireito = codigoBenDireito;
        this.dividasOnus = dividasOnus;
        this.codigoDividaOnu = codigoDividaOnu;
        this.doacoesEfetuadas = doacoesEfetuadas;
        this.codigoDoacoes = codigoDoacoes;
        this.investimentos = investimentos;
        this.codigoInvestimneto = codigoInvestimneto;
    }

    public String getDadosPessoais() {
        return dadosPessoais;
    }

    public void setDadosPessoais(String dadosPessoais) {
        this.dadosPessoais = dadosPessoais;
    }

    public String getCodigoPessoa() {
        return codigoPessoa;
    }

    public void setCodigoPessoa(String codigoPessoa) {
        this.codigoPessoa = codigoPessoa;
    }

    public String getDependentes() {
        return dependentes;
    }

    public void setDependentes(String dependentes) {
        this.dependentes = dependentes;
    }

    public String getCodigoDependente() {
        return codigoDependente;
    }

    public void setCodigoDependente(String codigoDependente) {
        this.codigoDependente = codigoDependente;
    }

    public String getRendimentos() {
        return rendimentos;
    }

    public void setRendimentos(String rendimentos) {
        this.rendimentos = rendimentos;
    }

    public String getCodigoRendimento() {
        return codigoRendimento;
    }

    public void setCodigoRendimento(String codigoRendimento) {
        this.codigoRendimento = codigoRendimento;
    }

    public String getBensDireitos() {
        return bensDireitos;
    }

    public void setBensDireitos(String bensDireitos) {
        this.bensDireitos = bensDireitos;
    }

    public String getCodigoBenDireito() {
        return codigoBenDireito;
    }

    public void setCodigoBenDireito(String codigoBenDireito) {
        this.codigoBenDireito = codigoBenDireito;
    }

    public String getDividasOnus() {
        return dividasOnus;
    }

    public void setDividasOnus(String dividasOnus) {
        this.dividasOnus = dividasOnus;
    }

    public String getCodigoDividaOnu() {
        return codigoDividaOnu;
    }

    public void setCodigoDividaOnu(String codigoDividaOnu) {
        this.codigoDividaOnu = codigoDividaOnu;
    }

    public String getDoacoesEfetuadas() {
        return doacoesEfetuadas;
    }

    public void setDoacoesEfetuadas(String doacoesEfetuadas) {
        this.doacoesEfetuadas = doacoesEfetuadas;
    }

    public String getCodigoDoacoes() {
        return codigoDoacoes;
    }

    public void setCodigoDoacoes(String codigoDoacoes) {
        this.codigoDoacoes = codigoDoacoes;
    }

    public String getInvestimentos() {
        return investimentos;
    }

    public void setInvestimentos(String investimentos) {
        this.investimentos = investimentos;
    }

    public String getCodigoInvestimneto() {
        return codigoInvestimneto;
    }

    public void setCodigoInvestimneto(String codigoInvestimneto) {
        this.codigoInvestimneto = codigoInvestimneto;
    }

    @Override
    public String toString() {
        return "EnvioDocumentos{" + "dadosPessoais=" + dadosPessoais + ", codigoPessoa=" + codigoPessoa + ", dependentes=" + dependentes + ", codigoDependente=" + codigoDependente + ", rendimentos=" + rendimentos + ", codigoRendimento=" + codigoRendimento + ", bensDireitos=" + bensDireitos + ", codigoBenDireito=" + codigoBenDireito + ", dividasOnus=" + dividasOnus + ", codigoDividaOnu=" + codigoDividaOnu + ", doacoesEfetuadas=" + doacoesEfetuadas + ", codigoDoacoes=" + codigoDoacoes + ", investimentos=" + investimentos + ", codigoInvestimneto=" + codigoInvestimneto + '}';
    }



}