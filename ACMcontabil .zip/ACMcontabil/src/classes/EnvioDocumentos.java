package classes;


public class EnvioDocumentos {
    private String linkDependente;
    private String linkRendimento;
    private String linkBenDireito;
    private String linkDividaOnu;
    private String linkDoacoes;
    private String linkInvestimento;

    public EnvioDocumentos(String linkDependente) {
        this.linkDependente = linkDependente;
    }
    
    

    public String getLinkDependente() {
        return linkDependente;
    }

    public void setLinkDependente(String linkDependente) {
        this.linkDependente = linkDependente;
    }

    public String getLinkRendimento() {
        return linkRendimento;
    }

    public void setLinkRendimento(String linkRendimento) {
        this.linkRendimento = linkRendimento;
    }

    public String getLinkBenDireito() {
        return linkBenDireito;
    }

    public void setLinkBenDireito(String linkBenDireito) {
        this.linkBenDireito = linkBenDireito;
    }

    public String getLinkDividaOnu() {
        return linkDividaOnu;
    }

    public void setLinkDividaOnu(String linkDividaOnu) {
        this.linkDividaOnu = linkDividaOnu;
    }

    public String getLinkDoacoes() {
        return linkDoacoes;
    }

    public void setLinkDoacoes(String linkDoacoes) {
        this.linkDoacoes = linkDoacoes;
    }

    public String getLinkInvestimento() {
        return linkInvestimento;
    }

    public void setLinkInvestimento(String linkInvestimento) {
        this.linkInvestimento = linkInvestimento;
    }

    
    
    


}