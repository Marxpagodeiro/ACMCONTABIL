package acmcontabil;

import telas.login;

/**
 *
 * @author 20222TPMI0035
 */
public class ACMcontabil {

    public static void main(String[] args) {


        login inicio = new login ();
        inicio.setVisible(true);
    }
    
}
