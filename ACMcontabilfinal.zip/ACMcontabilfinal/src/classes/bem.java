/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class bem {
    private String linkBenDireito;
    private int codigoUsuario;

    public bem(String linkBenDireito, int codigoUsuario) {
        this.linkBenDireito = linkBenDireito;
        this.codigoUsuario = codigoUsuario;
    }
    
    @Override
    public String toString() {
        String registro;
        registro = "linkBenDireito: "+this.linkBenDireito;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }

    public String getLinkBenDireito() {
        return linkBenDireito;
    }

    public void setLinkBenDireito(String linkBenDireito) {
        this.linkBenDireito = linkBenDireito;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    
    
    
}
