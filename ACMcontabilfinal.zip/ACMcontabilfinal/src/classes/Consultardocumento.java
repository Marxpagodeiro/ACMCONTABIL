/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class Consultardocumento {
    private String linkDependente;
    private String codigoDependente;
    private String dataDependente;
    private String linkRendimento;
    private String codigoRendimento;
    private String dataRendimento;
    private String linkBenDireito;
    private String codigoBenDireito;
    private String dataBenDireito;       
    private String linkDividaOnu;
    private String codigoDividaOnu;
    private String dataDividaOnu;
    private String linkDoacoes;
    private String codigoDoacoes;
    private String dataDoacoes;
    private String linkInvestimento;
    private String codigoInvestimento;
    private String dataInvestimento;
    private String codigoUsuario;

    public String getCodigoDependente() {
        return codigoDependente;
    }

    public void setCodigoDependente(String codigoDependente) {
        this.codigoDependente = codigoDependente;
    }

    public String getDataDependente() {
        return dataDependente;
    }

    public void setDataDependente(String dataDependente) {
        this.dataDependente = dataDependente;
    }

    public String getCodigoRendimento() {
        return codigoRendimento;
    }

    public void setCodigoRendimento(String codigoRendimento) {
        this.codigoRendimento = codigoRendimento;
    }

    public String getDataRendimento() {
        return dataRendimento;
    }

    public void setDataRendimento(String dataRendimento) {
        this.dataRendimento = dataRendimento;
    }

    public String getCodigoBenDireito() {
        return codigoBenDireito;
    }

    public void setCodigoBenDireito(String codigoBenDireito) {
        this.codigoBenDireito = codigoBenDireito;
    }

    public String getDataBenDireito() {
        return dataBenDireito;
    }

    public void setDataBenDireito(String dataBenDireito) {
        this.dataBenDireito = dataBenDireito;
    }

    public String getCodigoDividaOnu() {
        return codigoDividaOnu;
    }

    public void setCodigoDividaOnu(String codigoDividaOnu) {
        this.codigoDividaOnu = codigoDividaOnu;
    }

    public String getDataDividaOnu() {
        return dataDividaOnu;
    }

    public void setDataDividaOnu(String dataDividaOnu) {
        this.dataDividaOnu = dataDividaOnu;
    }

    public String getCodigoDoacoes() {
        return codigoDoacoes;
    }

    public void setCodigoDoacoes(String codigoDoacoes) {
        this.codigoDoacoes = codigoDoacoes;
    }

    public String getDataDoacoes() {
        return dataDoacoes;
    }

    public void setDataDoacoes(String dataDoacoes) {
        this.dataDoacoes = dataDoacoes;
    }

    public String getCodigoInvestimento() {
        return codigoInvestimento;
    }

    public void setCodigoInvestimento(String codigoInvestimento) {
        this.codigoInvestimento = codigoInvestimento;
    }

    public String getDataInvestimento() {
        return dataInvestimento;
    }

    public void setDataInvestimento(String dataInvestimento) {
        this.dataInvestimento = dataInvestimento;
    }

    
    
    
    public String getLinkDependente() {
        return linkDependente;
    }

    public void setLinkDependente(String linkDependente) {
        this.linkDependente = linkDependente;
    }

    public String getLinkRendimento() {
        return linkRendimento;
    }

    public void setLinkRendimento(String linkRendimento) {
        this.linkRendimento = linkRendimento;
    }

    public String getLinkBenDireito() {
        return linkBenDireito;
    }

    public void setLinkBenDireito(String linkBenDireito) {
        this.linkBenDireito = linkBenDireito;
    }

    public String getLinkDividaOnu() {
        return linkDividaOnu;
    }

    public void setLinkDividaOnu(String linkDividaOnu) {
        this.linkDividaOnu = linkDividaOnu;
    }

    public String getLinkDoacoes() {
        return linkDoacoes;
    }

    public void setLinkDoacoes(String linkDoacoes) {
        this.linkDoacoes = linkDoacoes;
    }

    public String getLinkInvestimento() {
        return linkInvestimento;
    }

    public void setLinkInvestimento(String linkInvestimento) {
        this.linkInvestimento = linkInvestimento;
    }

    public String getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(String codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    
    
    
    
    
}
