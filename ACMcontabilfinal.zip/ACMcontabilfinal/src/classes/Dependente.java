/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class Dependente {
    private String linkDependente;
    private int codigoUsuario;

    public Dependente(String linkDependente, int codigoUsuario) {
        this.linkDependente = linkDependente;
        this.codigoUsuario = codigoUsuario;
    }

    @Override
    public String toString() {
        String registro;
        registro = "linkDependente: "+this.linkDependente;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }

    

    public String getLinkDependente() {
        return linkDependente;
    }

    public void setLinkDependente(String linkDependente) {
        this.linkDependente = linkDependente;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    
    
}
