/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import classes.AreaCadastro;
import classes.Consultar;
import classes.Dependente;
import classes.Consultardocumento;
import classes.Login;
import classes.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Bruno
 */
public class usuarioDAO {
    
    Connection conn ;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<Usuario> lista = new ArrayList<>();
    ArrayList<Consultardocumento> depe = new ArrayList<>();
    ArrayList<Consultardocumento> ren = new ArrayList<>();
    ArrayList<Consultardocumento> ben = new ArrayList<>();
    ArrayList<Consultardocumento> doa = new ArrayList<>();
    ArrayList<Consultardocumento> div = new ArrayList<>();
    ArrayList<Consultardocumento> inv = new ArrayList<>();
    
    
    public ResultSet loginUsuario(Login objLogin){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Select * from usuarios where email=? and senha =?";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objLogin.getLogin());
            pstm.setString(2, objLogin.getSenha());
            
            rs = pstm.executeQuery();
            return rs;
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    public Usuario ConsultaUsuario(Consultar consulta){
        
        try {
            conn = new ConexaoDAO().conectaBD();
            String sql = "Select * from usuarios";
            pstm = conn.prepareStatement(sql);
            
            rs = pstm.executeQuery();
       
            Usuario usuario = new Usuario();
            usuario.setCodigoUsuario(rs.getString("codigoUsuario"));
            usuario.setNomeCompleto(rs.getString("nomeCompleto"));
            usuario.setCPF(rs.getString("CPF"));
            usuario.setDataNascimento(rs.getString("dataNascimento"));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            return usuario;

       
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    
    public ResultSet listarNome(){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Select * from usuarios ORDER BY nomeCompleto";
            pstm = conn.prepareStatement(sql);
            
            
            rs = pstm.executeQuery();
            return rs;
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    
    public void Exluirdados(Consultar consulta){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Delete from usuarios where codigoUsuario =? ";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, consulta.getCodigo());
            
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Excluir usuarioDAO: " + erro);
            
        }
    }
    public Usuario prencher(Consultar consulta){
        conn = new ConexaoDAO().conectaBD();
        
        try {
      
            String sql = "Select * from usuarios where codigoUsuario =? ";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,consulta.getCodigo());
            rs = pstm.executeQuery();
            if(rs.next()){
                Usuario usuario = new Usuario();
                usuario.setCodigoUsuario(rs.getString("codigoUsuario"));
                usuario.setNomeCompleto(rs.getString("nomeCompleto"));
                usuario.setCPF(rs.getString("CPF"));
                usuario.setDataNascimento(rs.getString("dataNascimento"));
                usuario.setTelefone(rs.getString("telefone"));
                usuario.setEmail(rs.getString("email"));
            return usuario;
            }
            else{
                return null;
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, " usuarioDAO: " + erro);
            return null;
        }
    }
    
    
    public ArrayList<Usuario> listar(Consultar consulta){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from usuarios where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, consulta.getCodigo());
            rs = pstm.executeQuery();
            while(rs.next()){
                Usuario listarusuario = new Usuario();
                listarusuario.setCodigoUsuario(rs.getString("codigoUsuario"));
                listarusuario.setNomeCompleto(rs.getString("nomeCompleto"));
                listarusuario.setCPF(rs.getString("CPF"));
                listarusuario.setDataNascimento(rs.getString("dataNascimento"));
                listarusuario.setTelefone(rs.getString("telefone"));
                listarusuario.setEmail(rs.getString("email"));
                
                lista.add(listarusuario);    
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return lista;
    }
    
    public ArrayList<Consultardocumento> listarDepen(Consultardocumento dep){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from dependentes where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,dep.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento dependente = new Consultardocumento();
                dependente.setCodigoDependente(rs.getString("codigoDependente"));
                dependente.setLinkDependente(rs.getString("linkDependente"));
                dependente.setDataDependente(rs.getString("dataDependente"));
                dependente.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                depe.add(dependente);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return depe;
    }
    public ArrayList<Consultardocumento> listarRend(Consultardocumento rend){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from rendimentos where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,rend.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento documentos = new Consultardocumento();
                documentos.setCodigoRendimento(rs.getString("codigoRendimento"));
                documentos.setLinkRendimento(rs.getString("linkRendimento"));
                documentos.setDataRendimento(rs.getString("dataRendimento"));
                documentos.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                ren.add(documentos);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return ren;
    }
    public ArrayList<Consultardocumento> listarben(Consultardocumento be){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from bensdireitos where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,be.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento documentos = new Consultardocumento();
                documentos.setCodigoBenDireito(rs.getString("codigoBenDireito"));
                documentos.setLinkBenDireito(rs.getString("linkBenDireito"));
                documentos.setDataBenDireito(rs.getString("dataBenDireito"));
                documentos.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                ben.add(documentos);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return ben;
    }
    public ArrayList<Consultardocumento> listardoa(Consultardocumento doas){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from doacoesefetuadas where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,doas.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento documentos = new Consultardocumento();
                documentos.setCodigoDoacoes(rs.getString("codigoDoacoes"));
                documentos.setLinkDoacoes(rs.getString("linkDoacoes"));
                documentos.setDataDoacoes(rs.getString("dataDoacoes"));
                documentos.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                doa.add(documentos);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return doa;
    }
    public ArrayList<Consultardocumento> listardiiv(Consultardocumento divi){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from dividasonus where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,divi.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento documentos = new Consultardocumento();
                documentos.setCodigoDividaOnu(rs.getString("codigoDividaOnu"));
                documentos.setLinkDividaOnu(rs.getString("linkDividaOnu"));
                documentos.setDataDividaOnu(rs.getString("dataDividaOnu"));
                documentos.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                div.add(documentos);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return div;
    }
    public ArrayList<Consultardocumento> listarinves(Consultardocumento inves){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from investimentos where codigoUsuario =? ";
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1,inves.getCodigoUsuario() );
            rs = pstm.executeQuery();
            while(rs.next()){
                Consultardocumento documentos = new Consultardocumento();
                documentos.setCodigoInvestimento(rs.getString("codigoInvestimento"));
                documentos.setLinkInvestimento(rs.getString("linkInvestimento"));
                documentos.setDataInvestimento(rs.getString("dataInvestimento"));
                documentos.setCodigoUsuario(rs.getString("codigoUsuario"));
             
                inv.add(documentos);
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return inv;
    }
}
