/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class divida {
    private String linkDividaOnu;
    private int codigoUsuario;

    public divida(String linkDividaOnu, int codigoUsuario) {
        this.linkDividaOnu = linkDividaOnu;
        this.codigoUsuario = codigoUsuario;
    }

   @Override
    public String toString() {
        String registro;
        registro = "linkDividaOnu: "+this.linkDividaOnu;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }
    
    public String getLinkDividaOnu() {
        return linkDividaOnu;
    }

    public void setLinkDividaOnu(String linkDividaOnu) {
        this.linkDividaOnu = linkDividaOnu;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    
}
