/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class doacoes {
    private String linkDoacoes;
    private int codigoUsuario;

    public doacoes(String linkDoacoes, int codigoUsuario) {
        this.linkDoacoes = linkDoacoes;
        this.codigoUsuario = codigoUsuario;
    }
    @Override
    public String toString() {
        String registro;
        registro = "linkDoações: "+this.linkDoacoes;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }

    public String getLinkDoacoes() {
        return linkDoacoes;
    }

    public void setLinkDoacoes(String linkDoacoes) {
        this.linkDoacoes = linkDoacoes;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    
    
}
