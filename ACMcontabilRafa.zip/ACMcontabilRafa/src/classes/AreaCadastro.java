package classes;


public class AreaCadastro {
    private String nomeCompleto;
    private String CPF;
    private String dataNascimento;
    private String telefone;
    private String email;
    private String senha;

    public AreaCadastro(String nomeCompleto, String CPF, String dataNascimento, String telefone, String email, String senha) {
        this.nomeCompleto = nomeCompleto;
        this.CPF = CPF;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
    } 

    @Override
    public String toString() {
        String registro;
        registro = "Nome: "+this.nomeCompleto;
        registro += "\nCPF: "+this.CPF;
        registro += "\nData de Nacimento: "+this.dataNascimento;
        registro += "\nTelefone: "+this.telefone;
        registro += "\nEmail: " + this.email;
        registro += "\nSenha: " + this.senha;
        return registro;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    

   

    
   

    

}