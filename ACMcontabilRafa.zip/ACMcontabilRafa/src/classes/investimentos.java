package classes;


public class investimentos {
    
    private String linkInvestimento;
    private int codigoUsuario;

    public investimentos(String linkInvestimento, int codigoUsuario) {
        this.linkInvestimento = linkInvestimento;
        this.codigoUsuario = codigoUsuario;
    }

    
    @Override
    public String toString() {
        String registro;
        registro = "linkInvestimento: "+this.linkInvestimento;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }
    
    public String getLinkInvestimento() {
        return linkInvestimento;
    }

    public void setLinkInvestimento(String linkInvestimento) {
        this.linkInvestimento = linkInvestimento;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    

    

   
    

    
    
    


}