/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Bruno
 */
public class Rendimento {
    private String linkRendimento;
    private int codigoUsuario;

    public Rendimento(String linkRendimento, int codigoUsuario) {
        this.linkRendimento = linkRendimento;
        this.codigoUsuario = codigoUsuario;
    }

    @Override
    public String toString() {
        String registro;
        registro = "linkRendimento: "+this.linkRendimento;
        registro += "\ncodigoUsuario: "+this.codigoUsuario;
        return registro;
    }

    public String getLinkRendimento() {
        return linkRendimento;
    }

    public void setLinkRendimento(String linkRendimento) {
        this.linkRendimento = linkRendimento;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
    
}
