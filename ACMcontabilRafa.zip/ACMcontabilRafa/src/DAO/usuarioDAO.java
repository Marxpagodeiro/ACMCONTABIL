/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import classes.AreaCadastro;
import classes.Consultar;
import classes.Login;
import classes.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Bruno
 */
public class usuarioDAO {
    
    Connection conn ;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<Usuario> lista = new ArrayList<>();
    
    public ResultSet loginUsuario(Login objLogin){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Select * from usuarios where email=? and senha =?";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objLogin.getLogin());
            pstm.setString(2, objLogin.getSenha());
            
            rs = pstm.executeQuery();
            return rs;
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    public Usuario ConsultaUsuario(Consultar consulta){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Select * from usuarios where CPF=?";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, consulta.getCPF());
            
            
            rs = pstm.executeQuery();
            if (rs.next()) {
            Usuario usuario = new Usuario();
            usuario.setCodigoUsuario(rs.getString("codigoUsuario"));
            usuario.setNomeCompleto(rs.getString("nomeCompleto"));
            usuario.setCPF(rs.getString("CPF"));
            usuario.setDataNascimento(rs.getString("dataNascimento"));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            return usuario;
        } else {
            return null; // ou lançar uma exceção indicando que o usuário não foi encontrado
        }
       
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    public ResultSet listarNome(){
        conn = new ConexaoDAO().conectaBD();
        
        try {
            String sql = "Select * from usuarios ORDER BY nomeCompleto";
            pstm = conn.prepareStatement(sql);
            
            
            rs = pstm.executeQuery();
            return rs;
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "usuarioDAO: " + erro);
            return null;
        }
    }
    
    public ArrayList<Usuario> listar(){
        conn = new ConexaoDAO().conectaBD();
        String sql = "Select * from usuarios ";
        try {
            
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            while(rs.next()){
                Usuario listarusuario = new Usuario();
                listarusuario.setCodigoUsuario(rs.getString("codigoUsuario"));
                listarusuario.setNomeCompleto(rs.getString("nomeCompleto"));
                listarusuario.setCPF(rs.getString("CPF"));
                listarusuario.setDataNascimento(rs.getString("dataNascimento"));
                listarusuario.setTelefone(rs.getString("telefone"));
                listarusuario.setEmail(rs.getString("email"));
                
                lista.add(listarusuario);    
            
            
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "pesquisa : " + erro);
        }
        return lista;
    }
    
}
